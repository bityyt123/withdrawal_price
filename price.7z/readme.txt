此程序比较食人魔交易所（Tradeogre）和币安交易所（Binance）共有USDT交易对的币种价格，用于在食人魔交易所提现到币安时，可以选择提现手续费较低并且交易磨损小的币种

如果未安装python，需先安装

python下载：https://www.python.org/downloads/

安装python编程环境，安装时开始界面勾选“Add python.exe to PATH"  （重要）

安装python后，打开cmd命令行窗口，执行 pip install requests  安装模块  （重要）

程序执行需要挂上代理，由于币安API地区限制，美国节点不行，其他应该可以，大家自行测试

程序执行 : run.bat

币安(Binance)交易所推广链接：https://accounts.suitechsui.io/register?ref=21962635
------------------------------------------------------------------------------------------------------------------
如果您觉得这个程序对您有帮助，欢迎打赏支持：

USDT地址（bsc、polygon、avax、arbitrum、op等以太坊二层链）：0xaa23590e28efF3b34A0e805E9f34a87C4354629e

Qubic地址：WTERIKOJZARTSBMRJBGVFBXHODRCZFSALCSXMKGAKEIBPDCYERQRIHRBMOBE
