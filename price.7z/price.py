import sys
import requests

def get_markets(url):
    r = requests.get(url)
    markets = r.json()
    return markets

bn_markets = get_markets("https://api.binance.com/api/v3/ticker/price")
if isinstance(bn_markets, dict) and bn_markets.get("code") == 0:
    print("由于币安地区限制，请更换地区节点")
    sys.exit()
usdt_pairs = [pair for pair in bn_markets if 'USDT' in pair['symbol']]
bn_j = {}
for bn_ticker in usdt_pairs:
    bn_j[bn_ticker['symbol'][:-4]] = float(bn_ticker['price'])
to_markets = get_markets("https://tradeogre.com/api/v1/markets")
to_usdt_pairs = [pair for pair in to_markets if 'USDT' in list(pair.keys())[0]]
to_j = {}
for to_ticker in to_usdt_pairs:
    to_j[list(to_ticker.keys())[0][:-5]] = float(list(to_ticker.values())[0]['ask'])
common_keys = set(to_j.keys()) & set(bn_j.keys())
price_ratios = {key: to_j[key] / bn_j[key] for key in common_keys}
sorted_keys = sorted(common_keys, key=lambda x: price_ratios[x])
print("-------------------------------------------------")
print("Coin          | Tradeogre Price | Binance Price")
print("-------------------------------------------------")
for key in sorted_keys:
    value_to = to_j[key]
    value_bn = bn_j[key]
    print(f"{key:<14}|  {value_to:<15}|  {value_bn:<15}")
print("-------------------------------------------------")
print("Made by TechHow")
print("YouTube：https://www.youtube.com/@TechHow123")
print("-------------------------------------------------")
